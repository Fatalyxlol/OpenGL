#include <GL/glew.h>
#include <SFML/OpenGL.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include "math.h"

#include <iostream>
#include <array>

#define deg2rad M_PI /180.0
#define circleVertexCount 360

GLuint Program;
GLint Attrib_vertex;
GLint Attrib_color;
GLint Attrib_texture;
GLint Unif_xmove;
GLint Unif_ymove;
GLint Unif_reg;
GLuint VBO;
int vertex_count;
GLuint byte;
sf::Texture ourTexture1;
sf::Texture ourTexture2;
GLuint textureHandle1;
GLuint textureHandle2;
GLint unif_sampler1;
GLint unif_sampler2;
GLint unif_twoTextures;


struct Vertex {
    GLfloat x;
    GLfloat y;
    GLfloat z;
    GLfloat r;
    GLfloat g;
    GLfloat b;
    GLfloat tex_x;
    GLfloat tex_y;
};
Vertex *vertex;

Vertex tetrahedron[9] = {
        {0.2,  0.45,  -0.5, 0.0, 0.0, 1.0},
        {-0.6, 0,     -0.5, 1.0, 0.0, 0.0},
        {0,    0,     0.5,  1.0, 1.0, 1.0},
        {-0.6, 0,     -0.5, 1.0, 0.0, 0.0},
        {0,    0,     0.5,  1.0, 1.0, 1.0},
        {0.2,  -0.45, -0.5, 0.0, 1.0, 0.0},
        {0,    0,     0.5,  1.0, 1.0, 1.0},
        {0.2,  0.45,  -0.5, 0.0, 0.0, 1.0},
        {0.2,  -0.45, -0.5, 0.0, 1.0, 0.0},
};

Vertex cube[36] = {
        {-0.5, -0.5, +0.5, 1,   0, 0,1,0},///
        {-0.5, +0.5, +0.5, 0,   1, 0,1,1},
        {+0.5, +0.5, +0.5, 0,   0, 1,0,1},//
        {+0.5, +0.5, +0.5, 0,   0, 1,0,1},//
        {+0.5, -0.5, +0.5, 1,   1, 0,0,0},
        {-0.5, -0.5, +0.5, 1,   0, 0,1,0},///

        {-0.5, -0.5, -0.5, 1,   0, 1,0,1},//
        {+0.5, +0.5, -0.5, 1,   1, 1,1,0},///
        {-0.5, +0.5, -0.5, 0,   1, 1,1,1},
        {+0.5, +0.5, -0.5, 1,   1, 1,1,0},///
        {-0.5, -0.5, -0.5, 1,   0, 1,0,1},//
        {+0.5, -0.5, -0.5, 0.5, 0, 1,0,0},

        {-0.5, +0.5, -0.5, 0,   1, 1,0,1},
        {-0.5, +0.5, +0.5, 0,   1, 0,0,0},
        {+0.5, +0.5, +0.5, 0,   0, 1,1,0},
        {+0.5, +0.5, +0.5, 0,   0, 1,1,0},
        {+0.5, +0.5, -0.5, 1,   1, 1,1,1},
        {-0.5, +0.5, -0.5, 0,   1, 1,0,1},

        {-0.5, -0.5, -0.5, 1,   0, 1,0,1},//
        {+0.5, -0.5, +0.5, 1,   1, 0,1,0},///
        {-0.5, -0.5, +0.5, 1,   0, 0,1,1},
        {+0.5, -0.5, +0.5, 1,   1, 0,1,0},///
        {-0.5, -0.5, -0.5, 1,   0, 1,0,1},//
        {+0.5, -0.5, -0.5, 0.5, 0, 1,0,0},

        {+0.5, -0.5, -0.5, 0.5, 0, 1,1,0},//
        {+0.5, -0.5, +0.5, 1,   1, 0,0,0},
        {+0.5, +0.5, +0.5, 0,   0, 1,0,1},///
        {+0.5, +0.5, +0.5, 0,   0, 1,0,1},///
        {+0.5, +0.5, -0.5, 1,   1, 1,1,1},
        {+0.5, -0.5, -0.5, 0.5, 0, 1,1,0},//

        {-0.5, -0.5, -0.5, 1,   0, 1,1,0},//
        {-0.5, +0.5, +0.5, 0,   1, 0,0,1},///
        {-0.5, -0.5, +0.5, 1,   0, 0,0,0},
        {-0.5, +0.5, +0.5, 0,   1, 0,0,1},///
        {-0.5, -0.5, -0.5, 1,   0, 1,1,0},//
        {-0.5, +0.5, -0.5, 0,   1, 1,1,1},
};

const char *VertexShaderSource = R"(
    #version 330 core
    in vec3 coord;
    in vec3 color;

    uniform float x_move;
    uniform float y_move;

    out vec4 vert_color;

    void main() {
        vec3 position = vec3(coord) + vec3(x_move, y_move, 0);
        gl_Position = vec4(position.xyz, 1.0);

        vert_color = vec4(color.rgb,1);
    }
)";

const char *VertexShaderSource3 = R"(
    #version 330 core
    in vec3 coord;
    in vec3 color;

    uniform float x_move;
    uniform float y_move;

    out vec4 vert_color;

    void main() {
        vec3 position = vec3(coord.x * x_move, coord.y * y_move, 0);
        gl_Position = vec4(position.xyz, 1.0)/** rot_y * rot_x */;

        vert_color = vec4(color.rgb,1);
    }
)";

const char *VertexShaderSource2 = R"(
    #version 330 core
    in vec3 coord;
    in vec3 color;
    in vec2 vertexTextureCoords;


    uniform float x_move;
    uniform float y_move;

    out vec4 vert_color;
    out vec2 vTextureCoordinate;

    void main() {
        vec3 position = vec3(coord) + vec3(x_move, y_move, 0);
        mat4 rot_y = mat4(cos(-45),0,-sin(-45),0,0,1,0,0,sin(-45),0,cos(-45),0,0,0,0,1);
        mat4 rot_x = mat4(1,0,0,0,0,cos(35.26),sin(35.26),0,0,-sin(35.26),cos(35.26),0,0,0,0,1);
        gl_Position = vec4(position.xyz, 1.0)* rot_y * rot_x;
        vTextureCoordinate = vertexTextureCoords;

        vert_color = vec4(color.rgb,1);
    }
)";

const char *FragShaderSource = R"(
    #version 330 core
    in vec4 vert_color;

    out vec4 color;
    void main() {
        color = vert_color;
    }
)";

const char* FragShaderSource2 = R"(
    #version 330 core

    in vec4 vert_color;
    in vec2 vTextureCoordinate;

    uniform sampler2D ourTexture1;
    uniform sampler2D ourTexture2;
    uniform float reg;
    uniform bool twoTextures;

    out vec4 color;
    void main() {
        if(twoTextures){
            color = mix(texture(ourTexture1, vTextureCoordinate), texture(ourTexture2, vTextureCoordinate), reg);
        } else {
            color = mix(texture(ourTexture1, vTextureCoordinate), vert_color, reg);
        }
    }
)";

const char* vertex_shader = VertexShaderSource;
const char* fragment_shader = FragShaderSource;

float moveX = 0;
float moveY = 0;
float reg = 0.5;
bool twoTextures = false;

void moveShape(float moveXinc, float moveYinc) {
    moveX += moveXinc;
    moveY += moveYinc;
}

void changeReg(float delta) {
    if(reg + delta < 0) {
        reg = 0;
    } else if(reg + delta > 1) {
        reg = 1;
    } else {
        reg += delta;
    }
}

float bytify(float color)
{
    return (1 / 100.0) * color;
}

std::array<float, 4> HSVtoRGB(float hue, float saturation = 100.0, float value = 100.0)
{
    int sw = (int)floor(hue / 60) % 6;
    float vmin = ((100.0f - saturation) * value) / 100.0;
    float a = (value - vmin) * (((int)hue % 60) / 60.0);
    float vinc = vmin + a;
    float vdec = value - a;
    switch (sw)
    {
        case 0: return { bytify(value), bytify(vinc), bytify(vmin), 1.0 };
        case 1: return { bytify(vdec), bytify(value), bytify(vmin), 1.0 };
        case 2: return { bytify(vmin), bytify(value), bytify(vinc), 1.0 };
        case 3: return { bytify(vmin), bytify(vdec), bytify(value), 1.0 };
        case 4: return { bytify(vinc), bytify(vmin), bytify(value), 1.0 };
        case 5: return { bytify(value), bytify(vmin), bytify(vdec), 1.0 };
    }
    return { 0, 0, 0 , 0};
}

void InitVBO() {
    glGenBuffers(1, &VBO);


    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, byte, vertex, GL_STATIC_DRAW);
}

void InitTextures()
{
    const char* filename = "texture5.png";
    if (!ourTexture1.loadFromFile(filename))
    {
        std::cout << "Load tex 1 failed" << std::endl;
        return;
    }
    textureHandle1 = ourTexture1.getNativeHandle();
    ourTexture1.copyToImage().getPixelsPtr();

    filename = "texture3.png";
    if (!ourTexture2.loadFromFile(filename))
    {
        std::cout << "Load tex 2 failed" << std::endl;
        return;
    }
    textureHandle2 = ourTexture2.getNativeHandle();

    glGenTextures(1, &textureHandle1);
    glGenTextures(1, &textureHandle2);

    glBindTexture(GL_TEXTURE_2D, textureHandle1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ourTexture1.getSize().x, ourTexture1.getSize().y, 0, GL_RGBA, GL_UNSIGNED_BYTE, ourTexture1.copyToImage().getPixelsPtr());
    glGenerateMipmap(GL_TEXTURE_2D);

    glBindTexture(GL_TEXTURE_2D, textureHandle2);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ourTexture2.getSize().x, ourTexture2.getSize().y, 0, GL_RGBA, GL_UNSIGNED_BYTE, ourTexture2.copyToImage().getPixelsPtr());
    glGenerateMipmap(GL_TEXTURE_2D);
}


void InitShader() {
    GLuint vShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vShader, 1, &vertex_shader, NULL);
    glCompileShader(vShader);
    std::cout << "vertex shader \n";

    GLuint fShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fShader, 1, &fragment_shader, NULL);
    glCompileShader(fShader);
    std::cout << "fragment shader \n";

    Program = glCreateProgram();
    glAttachShader(Program, vShader);
    glAttachShader(Program, fShader);

    glLinkProgram(Program);
    int link_ok;
    glGetProgramiv(Program, GL_LINK_STATUS, &link_ok);
    if (!link_ok) {
        std::cout << "error attach shaders \n";
        return;
    }

    Attrib_vertex = glGetAttribLocation(Program, "coord");
    //Attrib_vertex = 0;
    if (Attrib_vertex == -1) {
        std::cout << "could not bind attrib coord" << std::endl;
        return;
    }

    Attrib_color = glGetAttribLocation(Program, "color");
    Attrib_color = 1;
    if (Attrib_color == -1) {
        std::cout << "could not bind attrib color" << std::endl;
        return;
    }

    const char *unif_name = "x_move";
    Unif_xmove = glGetUniformLocation(Program, unif_name);
    if (Unif_xmove == -1) {
        std::cout << "could not bind uniform " << unif_name << std::endl;
        return;
    }

    unif_name = "y_move";
    Unif_ymove = glGetUniformLocation(Program, unif_name);
    //Unif_ymove = 3;
    if (Unif_ymove == -1) {
        std::cout << "could not bind uniform " << unif_name << std::endl;
        return;
    }

    if(fragment_shader == FragShaderSource2) {
        Attrib_texture = glGetAttribLocation(Program, "vertexTextureCoords");
        Attrib_texture = 2;
        if (Attrib_texture == -1) {
            std::cout << "could not bind attrib texture" << std::endl;
            return;
        }

        unif_sampler1 = glGetUniformLocation(Program, "ourTexture1");
        if (unif_sampler1 == -1) {
            std::cout << "could not bind uniform " << "ourTexture1" << std::endl;
            //return;
        }

        unif_sampler2 = glGetUniformLocation(Program, "ourTexture2");
        if (unif_sampler2 == -1) {
            std::cout << "could not bind uniform " << "ourTexture2" << std::endl;
            //return;
        }

        Unif_reg = glGetUniformLocation(Program, "reg");
        if (Unif_reg == -1) {
            std::cout << "could not bind uniform " << "reg" << std::endl;
            //return;
        }

        unif_twoTextures = glGetUniformLocation(Program, "twoTextures");
        if (unif_twoTextures == -1) {
            std::cout << "could not bind uniform " << "twoTextures" << std::endl;
            //return;
        }
    }
}

void Init() {
    InitShader();
    InitVBO();
    InitTextures();
    glEnable(GL_DEPTH_TEST);
}


void Draw() {
    glUseProgram(Program);

    glUniform1f(Unif_xmove, moveX);
    glUniform1f(Unif_ymove, moveY);

    glEnableVertexAttribArray(Attrib_vertex);
    glEnableVertexAttribArray(Attrib_color);
    if(fragment_shader == FragShaderSource2) {
        glEnableVertexAttribArray(Attrib_texture);
        glUniform1i(unif_twoTextures, twoTextures);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, textureHandle1);
        glUniform1i(unif_sampler1, 0);
        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, textureHandle2);
        glUniform1i(unif_sampler2, 1);
        glUniform1f(Unif_reg, reg);
    }

    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glVertexAttribPointer(Attrib_vertex, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), 0);
    glVertexAttribPointer(Attrib_color, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void *) (sizeof(GLfloat) * 3));
    if(fragment_shader == FragShaderSource2) {
        glVertexAttribPointer(Attrib_texture, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (void *) (sizeof(GLfloat) * 6));
    }


    glDrawArrays(GL_TRIANGLES, 0, vertex_count);

    glDisableVertexAttribArray(Attrib_vertex);
    glDisableVertexAttribArray(Attrib_color);
    if(fragment_shader == FragShaderSource2) {
        glDisableVertexAttribArray(Attrib_texture);
    }

    glUseProgram(0);
}


int main() {
    sf::Window window(sf::VideoMode(1000, 1000), "My OpenGL window", sf::Style::Default, sf::ContextSettings(24));
    window.setVerticalSyncEnabled(true);

    Vertex circle[circleVertexCount * 3] = {};
    for (int i = 0; i < circleVertexCount; i++) {
        auto c1 = HSVtoRGB(i % 360);
        circle[i * 3] = { 0.5f * (float)cos(i * (360.0 / circleVertexCount) * deg2rad), 0.5f * (float)sin(i * (360.0 / circleVertexCount) * deg2rad), 0, c1[0], c1[1], c1[2]};
        auto c2 = HSVtoRGB((i + 1) % 360);
        circle[i * 3 + 1] = { 0.5f * (float)cos((i+1) * (360.0 / circleVertexCount) * deg2rad), 0.5f * (float)sin((i + 1) * (360.0 / circleVertexCount) * deg2rad), 0, c2[0], c2[1], c2[2]};
        circle[i * 3 + 2] = { 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f };
    }

    window.setActive(true);
    glewInit();

    Init();

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            } else if (event.type == sf::Event::Resized) {
                glViewport(0, 0, event.size.width, event.size.height);
            } else if (event.type == sf::Event::KeyPressed) {
                switch (event.key.code) {
                    case sf::Keyboard::F1:
                        vertex = tetrahedron;
                        vertex_count = 9;
                        byte = sizeof(tetrahedron);
                        Init();
                        break;
                    case sf::Keyboard::F2:
                        vertex = cube;
                        vertex_count = 36;
                        byte = sizeof(cube);
                        Init();
                        break;
                    case sf::Keyboard::F3:
                        vertex_shader = VertexShaderSource;
                        fragment_shader = FragShaderSource;
                        InitShader();
                        break;
                    case sf::Keyboard::F4:
                        vertex_shader = VertexShaderSource2;
                        fragment_shader = FragShaderSource2;
                        twoTextures = false;
                        InitShader();
                        break;
                    case sf::Keyboard::F5:
                        twoTextures = true;
                        break;
                    case sf::Keyboard::F6:
                        vertex_shader = VertexShaderSource3;
                        fragment_shader = FragShaderSource;
                        moveX = 1;
                        moveY = 1;
                        vertex = circle;
                        vertex_count = circleVertexCount * 3;
                        byte = sizeof(circle);
                        Init();
                        break;
                    case (sf::Keyboard::W):
                        (0, 0.1);
                        break;
                    case (sf::Keyboard::S):
                        moveShape(0, -0.1);
                        break;
                    case (sf::Keyboard::A):
                        if(fragment_shader == FragShaderSource2) {
                            changeReg(-0.05);
                        } else {
                            moveShape(-0.1, 0);
                        }
                        break;
                    case (sf::Keyboard::D):
                        if(fragment_shader == FragShaderSource2) {
                            changeReg(0.05);
                        } else {
                            moveShape(0.1, 0);
                        }
                        break;
                    default:
                        break;
                }
            }
        }

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        Draw();

        window.display();
    }

    return 0;
}